import os
from flask import Flask, request, render_template, jsonify, redirect, url_for
from supabase import create_client, Client

app = Flask(__name__)

# ======================================
# KONFIGURASI SUPABASE
# ======================================

SUPABASE_URL = os.getenv(
    "SUPABASE_URL",
    ""
)

SUPABASE_KEY = os.getenv(
    "SUPABASE_KEY",
    ""
)

supabase: Client = create_client(
    SUPABASE_URL,
    SUPABASE_KEY
)

TABLE = "whitelist"

# ======================================
# DATABASE
# ======================================

def get_whitelist():
    try:

        result = (
            supabase.table(TABLE)
            .select("*")
            .order("id")
            .execute()
        )

        return result.data or []

    except Exception as e:

        print("GET ERROR:", e)

        return []


def device_exists(device_id):

    try:

        result = (
            supabase.table(TABLE)
            .select("device_id")
            .eq("device_id", device_id)
            .execute()
        )

        return len(result.data) > 0

    except Exception as e:

        print("CHECK ERROR:", e)

        return False

def add_whitelist(device_id, name, status):
    try:
        if device_exists(device_id):
            return False, "Device sudah terdaftar"

        supabase.table(TABLE).insert({
            "device_id": device_id,
            "name": name,
            "status": status
        }).execute()

        return True, "Berhasil"

    except Exception as e:
        print("INSERT ERROR:", e)
        return False, str(e)


def delete_whitelist(device_id):

    try:

        result = (
            supabase.table(TABLE)
            .delete()
            .eq("device_id", device_id)
            .execute()
        )

        return True, "Berhasil"

    except Exception as e:

        print("DELETE ERROR:", e)

        return False, str(e)


def total_device():

    return len(get_whitelist())

# ======================================
# ROUTES
# ======================================

@app.route("/")
def index():

    data = get_whitelist()

    return render_template(
        "dashboard.html",
        data=data,
        total=len(data),
        msg=None,
        err=None
    )


@app.route("/add", methods=["POST"])
def add_device():

    device_id = request.form.get("device_id", "").strip()
    name = request.form.get("name", "").strip()
    status = request.form.get("status", "Active").strip()

    if not name:
        name = "Anonymous"

    if not status:
        status = "Premium"

    msg = None
    err = None

    if device_id:

        try:
            if device_exists(device_id):
                err = "Device sudah terdaftar"
            else:
                supabase.table(TABLE).insert({
                    "device_id": device_id,
                    "name": name,
                    "status": status
                }).execute()

                msg = f"✅ {device_id} berhasil ditambahkan"

        except Exception as e:
            err = str(e)

    data = get_whitelist()

    return render_template(
        "dashboard.html",
        data=data,
        total=len(data),
        msg=msg,
        err=err
    )

@app.route("/delete", methods=["POST"])
def delete_device():

    device_id = request.form.get(
        "device_id",
        ""
    ).strip()

    msg = None
    err = None

    if device_id:

        ok, text = delete_whitelist(device_id)

        if ok:
            msg = f"🗑️ {device_id} berhasil dihapus"
        else:
            err = text

    data = get_whitelist()

    return render_template(
        "dashboard.html",
        data=data,
        total=len(data),
        msg=msg,
        err=err
    )

@app.route("/whitelist")
def whitelist():

    data = get_whitelist()

    return jsonify({
        "ids": [
            item["device_id"]
            for item in data
        ]
    })


@app.route("/status")
def status():

    data = get_whitelist()

    return jsonify({
        "success": True,
        "total": len(data),
        "data": data
    })

@app.errorhandler(Exception)
def handle_error(e):

    print(e)

    return jsonify({
        "success": False,
        "error": str(e)
    }), 500

@app.route("/whitelist_full")
def whitelist_full():
    data = get_whitelist()
    return jsonify({"data": data})


if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 5000)),
        debug=False
    )